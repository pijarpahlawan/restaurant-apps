const DB_CONFIG = {
  DB_NAME: 'restaurant-app-database',
  DB_VERSION: 1,
  OBJECT_STORE_NAME: 'restaurants',
};

export default DB_CONFIG;
