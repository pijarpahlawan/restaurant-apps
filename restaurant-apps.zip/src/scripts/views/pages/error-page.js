import template from "./templates/error-page.html";
import "./styles/error-page.scss";

const ErrorPage = {
    async render() {
        return template;
    },
};

export default ErrorPage;
